<?php

namespace App\Controllers;

use App\Models\UserModel;

class Auth extends BaseController
{
    public function register()
    {
        return view('auth/register');
    }

    public function login()
{
    echo "Login method is accessible";  // Test if this displays
    return view('auth/login');
}

    public function store()
{
    $userModel = new UserModel();
    $email = $this->request->getPost('email');

    // Check if email already exists
    if ($userModel->where('email', $email)->first()) {
        return redirect()->back()->with('error', 'Email already registered. Please use a different email.');
    }

    // Proceed with registration
    $data = [
        'name'     => $this->request->getPost('name'),
        'email'    => $email,
        'password' => password_hash($this->request->getPost('password'), PASSWORD_DEFAULT),
        'role'     => $this->request->getPost('role') ?? 'user',  // Assign role; default to 'user'
    ];

    $userModel->insert($data);
    return redirect()->to('/login')->with('success', 'Registration successful. Please log in.');
}

public function authenticate()
{
    $userModel = new UserModel();
    $email = $this->request->getPost('email');
    $password = $this->request->getPost('password');

    $user = $userModel->where('email', $email)->first();

    if ($user && password_verify($password, $user['password'])) {
        session()->set([
            'user_id' => $user['id'],
            'user_name' => $user['name'],
            'role' => $user['role'],
            'logged_in' => true,
        ]);

        // Redirect based on role
        if ($user['role'] === 'admin') {
            return redirect()->to('/admin/dashboard');
        } else {
            return redirect()->to('/dashboard');
        }
    } else {
        return redirect()->back()->with('error', 'Invalid email or password.');
    }
}

    public function logout()
    {
        session()->destroy();
        return redirect()->to('/login')->with('success', 'Logged out successfully.');
    }
}
