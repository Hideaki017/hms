<?php

namespace App\Controllers;

use CodeIgniter\Controller;

class AdminController extends Controller
{
    public function __construct()
    {
        // Load helpers, models, or any other dependencies if needed
        helper(['url', 'form']);
    }

    public function dashboard()
    {
        // Check if the user is logged in and is an admin
        if (!session()->get('logged_in') || session()->get('role') !== 'admin') {
            return redirect()->to('/login')->with('error', 'Access denied. Admins only.');
        }

        // Load any data needed for the dashboard view
        $data = [
            'title' => 'Admin Dashboard',
            'admin_name' => session()->get('user_name'),
        ];

        return view('admin/dashboard', $data);
    }

    // Additional admin-specific methods can go here

    public function manageUsers()
    {
        // Example method for managing users (admins only)
        if (!session()->get('logged_in') || session()->get('role') !== 'admin') {
            return redirect()->to('/login')->with('error', 'Access denied. Admins only.');
        }

        // Fetch users from the database and pass to the view
        $userModel = new \App\Models\UserModel();
        $users = $userModel->findAll();

        $data = [
            'title' => 'Manage Users',
            'users' => $users,
        ];

        return view('admin/manage_users', $data);
    }
}
