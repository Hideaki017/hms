<?php
// app/Controllers/SettingsController.php
namespace App\Controllers;

use App\Controllers\BaseController;

class SettingsController extends BaseController
{
    public function index()
    {
        return view('settings');
    }
    public function update()
{
    $userModel = new \App\Models\UserModel();
    $userId = session()->get('user_id');

    $data = [
        'name'  => $this->request->getPost('name'),
        'email' => $this->request->getPost('email'),
    ];

    // Update user details
    $userModel->update($userId, $data);

    // Update session data
    session()->set($data);

    return redirect()->to('/settings')->with('success', 'Account settings updated successfully.');
}
}
