<?php
// app/Controllers/ProfileController.php
namespace App\Controllers;

use App\Controllers\BaseController;

class ProfileController extends BaseController
{
    public function index()
    {
        return view('profile');
    }
}
