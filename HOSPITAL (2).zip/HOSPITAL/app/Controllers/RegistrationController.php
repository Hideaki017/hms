<?php
namespace App\Controllers;

use App\Models\UserModel;
use CodeIgniter\Controller;

class RegisterController extends Controller
{
    public function store()
    {
        helper(['form', 'url']);

        $validation =  \Config\Services::validation();

        // Validate the form data
        if ($this->validate([
            'name'     => 'required|min_length[3]|max_length[255]',
            'email'    => 'required|valid_email|is_unique[users.email]',
            'password' => 'required|min_length[6]',
            'role'     => 'required|in_list[doctor,patient]'
        ])) {
            $model = new UserModel();

            // Store user data
            $model->save([
                'name'     => $this->request->getVar('name'),
                'email'    => $this->request->getVar('email'),
                'password' => password_hash($this->request->getVar('password'), PASSWORD_DEFAULT),
                'role'     => $this->request->getVar('role') // Capture the role
            ]);

            return redirect()->to('/login')->with('success', 'Registration successful. Please log in.');
        } else {
            return redirect()->back()->withInput()->with('error', 'Validation failed!');
        }
    }
}
