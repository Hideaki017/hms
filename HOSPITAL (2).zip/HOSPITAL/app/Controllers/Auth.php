<?php

namespace App\Controllers;

use App\Models\UserModel;

class Auth extends BaseController
{
    public function register()
    {
        return view('auth/register');
    }

    public function store()
    {
        $userModel = new \App\Models\UserModel();
        $email = $this->request->getPost('email');

        // Check if email already exists
        if ($userModel->where('email', $email)->first()) {
            return redirect()->back()->with('error', 'Email already registered. Please use a different email.');
        }

        // Default role for a new user (can be "patient" or assigned as needed)
        $role = 'patient';  // You can change this to 'doctor' for doctors or make it dynamic based on input

        // Proceed with registration
        $data = [
            'name'     => $this->request->getPost('name'),
            'email'    => $email,
            'password' => password_hash($this->request->getPost('password'), PASSWORD_DEFAULT),
            'role'     => $role,  // Store the user's role (default "patient")
        ];

        $userModel->insert($data);
        return redirect()->to('/login')->with('success', 'Registration successful. Please log in.');
    }

    public function login()
    {
        return view('auth/login');
    }

    public function authenticate()
    {
        $userModel = new UserModel();
        $email = $this->request->getPost('email');
        $password = $this->request->getPost('password');

        $user = $userModel->where('email', $email)->first();

        if ($user && password_verify($password, $user['password'])) {
            // Set session data after successful login, including the user's role
            session()->set([
                'user_id'    => $user['id'],
                'user_name'  => $user['name'],
                'user_email' => $user['email'],
                'role'       => $user['role'],  // Store the user's role in session
                'logged_in'  => true,
            ]);
            return redirect()->to('/dashboard');
        } else {
            return redirect()->back()->with('error', 'Invalid email or password.');
        }
    }

    public function logout()
    {
        session()->destroy();
        return redirect()->to('/login')->with('success', 'Logged out successfully.');
    }
    public function up()
{
    $this->forge->addField([
        'id'          => [
            'type'           => 'INT',
            'unsigned'       => true,
            'auto_increment' => true,
        ],
        'name'        => [
            'type'           => 'VARCHAR',
            'constraint'     => '255',
        ],
        'email'       => [
            'type'           => 'VARCHAR',
            'constraint'     => '255',
            'unique'         => true,
        ],
        'password'    => [
            'type'           => 'VARCHAR',
            'constraint'     => '255',
        ],
        'role'        => [
            'type'           => 'VARCHAR',
            'constraint'     => '50',
            'default'        => 'patient', // Default role
        ],
    ]);
    $this->forge->addPrimaryKey('id');
    $this->forge->createTable('users');
}

}
