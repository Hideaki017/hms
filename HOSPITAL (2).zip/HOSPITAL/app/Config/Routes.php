<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');

$routes->get('/register', 'Auth::register');
$routes->post('/register/store', 'Auth::store');
$routes->get('/login', 'Auth::login');
$routes->post('/login/authenticate', 'Auth::authenticate');
$routes->get('/logout', 'Auth::logout');
$routes->get('/dashboard', 'Dashboard::index');
$routes->get('/profile', 'ProfileController::index');
$routes->get('/settings', 'SettingsController::index');
$routes->post('/settings/update', 'SettingsController::update');

